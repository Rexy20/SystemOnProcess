﻿using Dbsys.AppData;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dbsys.Forms
{
    public partial class InsertBook : Form
    {
        public bool hasChange = false;
        private String IMG_PATH = AppDomain.CurrentDomain.BaseDirectory + "\\Image";
        public InsertBook()
        {
            InitializeComponent();
            if (!Directory.Exists(IMG_PATH))
                Directory.CreateDirectory(IMG_PATH);
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();

            String path = ofd.FileName;

            label1.Text = path;
            pictureBox1.Image = new Bitmap(path);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                String oldpath = label1.Text;

                String newFile = $"Img_{DateTime.Now.ToString("yyyy-M-d_H-m-ss")}.jpg";

                String newFilepath = Path.Combine(IMG_PATH, newFile);

                System.IO.File.Copy(oldpath, newFilepath);
                //MessageBox.Show("Uploaded!");


                using (var db = new DBSYSEntities())
                {
                    var newBook = new BookInfo();
                    newBook.bookName = txtBookName.Text;
                    newBook.authorName = txtAuthorName.Text;
                    newBook.Quantity = Convert.ToInt32(txtQuantity.Text);
                    newBook.bookImg = newFile;

                    db.BookInfo.Add(newBook);
                    db.SaveChanges();

                    hasChange = true;
                }
                MessageBox.Show("Uploaded!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void InsertBook_Load(object sender, EventArgs e)
        {

        }
    }
}
