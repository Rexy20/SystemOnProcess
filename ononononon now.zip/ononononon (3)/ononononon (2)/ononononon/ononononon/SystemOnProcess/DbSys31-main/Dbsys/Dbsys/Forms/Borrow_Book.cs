﻿using Dbsys.AppData;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dbsys.Forms
{
    public partial class Borrow_Book : Form
    {
        public bool hasChange = false;
        private String IMG_PATH = AppDomain.CurrentDomain.BaseDirectory + "\\Image";
        public List<BookInfo> listBooks;
        public Borrow_Book()
        {
            InitializeComponent();
            if (!Directory.Exists(IMG_PATH))
                Directory.CreateDirectory(IMG_PATH);
        }

        private void cbBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int selectedId = Convert.ToInt32(cbBooks.SelectedValue);



                BookInfo selectedBook = listBooks.Where(c => c.bookId == selectedId).FirstOrDefault();

                //txtBookName.Text = selectedBook.bookName;
                //txtAuthorName.Text = selectedBook.authorName;
                //txtQuantity.Text = selectedBook.Quantity.ToString();
                pictureBox1.Image = new Bitmap(AppDomain.CurrentDomain.BaseDirectory + "\\Image\\" + selectedBook.bookImg);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void loadCbBox()
        {
            using (var db = new DBSYSEntities())
            {

                listBooks = db.BookInfo.ToList();

                cbBooks.DisplayMember = "bookTitle";
                cbBooks.ValueMember = "bookId";
                cbBooks.DataSource = listBooks;
            }
        }

        private void Borrow_Book_Load(object sender, EventArgs e)
        {
            loadCbBox();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //String oldpath = label1.Text;

                String newFile = $"Img_{DateTime.Now.ToString("yyyy-M-d_H-m-ss")}.jpg";

                //String newFilepath = Path.Combine(IMG_PATH, newFile);

                //System.IO.File.Copy(oldpath, newFilepath);
                //MessageBox.Show("Uploaded!");


                using (var db = new DBSYSEntities())
                {
                    var newBorrow = new BorrowBooks();
                    newBorrow.bookName = textBookName.Text;
                    newBorrow.studentFname = textFirstName.Text;
                    newBorrow.studentLname = textLastName.Text;
                    newBorrow.userAddress = textAddress.Text;
                    newBorrow.userEmail = textEmail.Text;
                    newBorrow.studentId = Convert.ToInt32(textStudentId.Text);
                    newBorrow.Quantity = Convert.ToInt32(textQuantity.Text);
                    newBorrow.bookImg = newFile;

                    db.BorrowBooks.Add(newBorrow);
                    db.SaveChanges();

                    hasChange = true;
                }

                //using (var db = new DBSYSEntities())
                //{
                //    var newHistory = new BorrowHistory();
                //    newHistory.borrowId = txtBorrow.Text;
                //    newHistory.studentFname = textFirstName.Text;
                //    newHistory.studentLname = textLastName.Text;
                //    newHistory.userAddress = textAddress.Text;
                //    newHistory.userEmail = textEmail.Text;
                //    newHistory.studentId = Convert.ToInt32(textStudentId.Text);
                //    newHistory.Quantity = Convert.ToInt32(textQuantity.Text);
                //    newHistory.bookImg = newFile;

                //    db.BorrowBooks.Add(newBorrow);
                //    db.SaveChanges();

                //    hasChange = true;
                //}


                MessageBox.Show("Uploaded!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
