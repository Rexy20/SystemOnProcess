﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dbsys.Forms
{
    public partial class Frm_Staff_Dashboard : Form
    {
        public Frm_Staff_Dashboard()
        {
            InitializeComponent();
        }

        private void viewBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertBook ins = new InsertBook();
            ins.Show();
        }

        private void viewBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listOfBooks lis = new listOfBooks();
            lis.Show();
        }

        private void userToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Frm_Staff_Dashboard_Load(object sender, EventArgs e)
        {

        }
    }
}
