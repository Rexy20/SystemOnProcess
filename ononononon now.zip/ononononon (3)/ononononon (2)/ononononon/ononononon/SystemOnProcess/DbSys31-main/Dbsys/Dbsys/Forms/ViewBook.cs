﻿using Dbsys.AppData;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dbsys.Forms
{
    public partial class ViewBook : Form
    {
        public List<BookInfo> listBooks;
        private DBSYSEntities db;
        public ViewBook()
        {
            InitializeComponent();
            db = new DBSYSEntities();
        }

        private void btnSearchBook_Click(object sender, EventArgs e)
        {
            
        }

        private void cbBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int selectedId = Convert.ToInt32(cbBooks.SelectedValue);



                BookInfo selectedBook = listBooks.Where(c => c.bookId == selectedId).FirstOrDefault();

                //txtBookName.Text = selectedBook.bookName;
                //txtAuthorName.Text = selectedBook.authorName;
                //txtQuantity.Text = selectedBook.Quantity.ToString();
                pictureBox1.Image = new Bitmap(AppDomain.CurrentDomain.BaseDirectory + "\\Image\\" + selectedBook.bookImg);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void loadCbBox()
        {
            using (var db = new DBSYSEntities())
            {

                listBooks = db.BookInfo.ToList();

                cbBooks.DisplayMember = "bookTitle";
                cbBooks.ValueMember = "bookId";
                cbBooks.DataSource = listBooks;
            }
        }

        private void ViewBook_Load(object sender, EventArgs e)
        {
            loadCbBox();
        }
    }
}
