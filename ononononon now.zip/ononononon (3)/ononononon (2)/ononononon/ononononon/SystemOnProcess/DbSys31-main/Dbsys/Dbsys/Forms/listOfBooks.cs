﻿using Dbsys.AppData;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dbsys.Forms
{
    public partial class listOfBooks : Form
    {
        public List<BookInfo> listBooks;
        public listOfBooks()
        {
            InitializeComponent();
            listBooks = new List<BookInfo>();
        }

        private void listOfBooks_Load(object sender, EventArgs e)
        {
            loadCbBox();
        }

        private void loadCbBox()
        {
            using (var db = new DBSYSEntities())
            {

                listBooks = db.BookInfo.ToList();

                cbBooks.DisplayMember = "bookTitle";
                cbBooks.ValueMember = "bookId";
                cbBooks.DataSource = listBooks;
            }
        }

        private void cbBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int selectedId = Convert.ToInt32(cbBooks.SelectedValue);



                BookInfo selectedBook = listBooks.Where(c => c.bookId == selectedId).FirstOrDefault();

                txtBookName.Text = selectedBook.bookName;
                txtAuthorName.Text = selectedBook.authorName;
                txtQuantity.Text = selectedBook.Quantity.ToString();
                pictureBox1.Image = new Bitmap(AppDomain.CurrentDomain.BaseDirectory + "\\Image\\" + selectedBook.bookImg);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var frm = new InsertBook())
            {
                frm.ShowDialog();

                if (frm.hasChange)
                    loadCbBox();
            }
        }
    }
}
